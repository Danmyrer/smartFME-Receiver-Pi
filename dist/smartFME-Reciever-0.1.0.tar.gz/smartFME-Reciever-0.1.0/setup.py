# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['smartFME_Reciever']

package_data = \
{'': ['*']}

install_requires = \
['RPi.GPIO>=0.7.1,<0.8.0',
 'asyncio>=3.4.3,<4.0.0',
 'azure-iot-device>=2.11.0,<3.0.0',
 'opencv-python-headless==4.6.0.66',
 'pytesseract>=0.3.9,<0.4.0']

setup_kwargs = {
    'name': 'smartfme-reciever',
    'version': '0.1.0',
    'description': 'Get your FME-Alterts over your Smartphone!',
    'long_description': None,
    'author': 'Danmyrer',
    'author_email': 'dangwrb.09@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
