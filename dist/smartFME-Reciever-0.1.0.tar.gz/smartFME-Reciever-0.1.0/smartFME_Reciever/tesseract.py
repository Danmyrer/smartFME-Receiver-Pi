# TODO
# - texterkennung von img[]
# - returns (string) tesseract