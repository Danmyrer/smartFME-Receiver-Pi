# TODO
# - überwacht GPIO (FME) auf Einsatz
# - Triggert emergency.py