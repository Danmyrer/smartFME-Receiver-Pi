# TODO
# - macht Fotos von ALLEN Seiten
# - returns img[]
