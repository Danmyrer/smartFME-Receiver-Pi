# TODO
# - setzt FMEMonitor.py für startup
# - config der einzelnen scripte
