import cv2

USE_DUMMY = True
LOG_IMAGES = True
LOG = "[preProcess]"


def preProcess(img):
    print(f"{LOG} PreProcessing images")

    temp = []
    for i in img:
        n = cv2.cvtColor(i, cv2.COLOR_BGR2GRAY)
        temp.append(n)
    img = temp

    temp = []
    for i in img:
        n = cv2.threshold(i, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1]
        temp.append(n)
    img = temp

    temp = []
    for i in img:
        n = cv2.erode(i, None, iterations=5)
        temp.append(n)
    img = temp

    if LOG_IMAGES is True:
        for i in range(len(img)):
            print(f"{LOG} Logging images", end=" ")
            print(str(i + 1) + " / " + str(len(img)))
            cv2.imwrite("closed" + str(i) + ".png", img[i])
